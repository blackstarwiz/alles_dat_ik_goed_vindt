﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeulemansJasonOOP
{
    internal interface ISafe
    {
        public void VerzegelInhoudt();
        public int GeefAantalAttemps();
    }
}
